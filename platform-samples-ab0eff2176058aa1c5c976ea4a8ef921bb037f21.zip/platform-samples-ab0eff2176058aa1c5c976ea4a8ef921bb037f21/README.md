platform-samples
================

This is a public place for all sample projects related to the GitHub Platform.

## Hierarchy

The directories are organized to correlate with guides found on developer.github.com.
But here it is, broken down:

* _api_: here's a bunch of sample code relating to the API. Subdirectories in this
category are broken up by language. Do you have a language sample you'd like added?
Make a pull request and we'll consider it. 